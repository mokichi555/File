onmessage = function(event){
    var reader = new FileReaderSync();
    var data = event.data;
    var val = "";
    if(/^image/.test(data.type)){
        val = reader.readAsDataURL(data.file);
    }
    
    if(/^text/.test(data.type)){
        val = reader.readAsText(data.file);
    }
    postMessage({"type": data.type, "val": val});
}