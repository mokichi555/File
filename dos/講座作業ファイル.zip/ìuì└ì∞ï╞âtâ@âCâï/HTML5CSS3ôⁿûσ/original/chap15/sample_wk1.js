onmessage = function(event){
    var i=0
    var c = 0;
    for(i=1;i<=event.data;i++){
        if(i%3==0) c++;
    }
    postMessage("3の倍数は" + c + "個です");
}