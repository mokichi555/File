importScripts("sample1_3.js");
onmessage = function(event){
    postMessage(cal(event.data));
}