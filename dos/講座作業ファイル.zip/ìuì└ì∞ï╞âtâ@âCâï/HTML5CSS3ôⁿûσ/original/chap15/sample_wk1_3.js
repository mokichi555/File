function cal(num){
    var i=0
    var c = 0;
    for(i=1;i<=num;i++){
        if(i%3==0) c++;
    }
    return "3の倍数は" + c + "個です";
}