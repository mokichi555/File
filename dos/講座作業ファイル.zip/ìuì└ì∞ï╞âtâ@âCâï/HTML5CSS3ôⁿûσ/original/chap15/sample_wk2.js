var array = [];
onconnect = function(event){
    array.push(event.ports[0]);
    for (var i = 0 ; i < array.length ; i++) {
      array[i].postMessage("共有数： " +  array.length);
    }
}

