<?php
require 'WebSocketServer.php';

$server = new WebsocketServer('host', port, 'process');
$server->run();

function process(WebsocketUser $user, $msg, WebsocketServer $server);
{
    foreach($server->getUsers() as $user){
        $server->send($user->socket, $msg);
    }
}
?>