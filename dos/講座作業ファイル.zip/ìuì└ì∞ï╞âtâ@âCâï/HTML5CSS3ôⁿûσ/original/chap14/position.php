<?php
require 'WebSocketServer.php';

$server = new WebsocketServer('host', port, 'process');
$server->run();

function process(WebsocketUser $user, $msg, WebsocketServer $server){
    $user->data['position'] = $msg;
    
    $return = array();
    foreach($server->getUsers() as $user){
        if (! isset($user->data['color'])) {
            $user->data['color'] = randomColor();
        }
        $return[$user->id] = $user->data;
    }
    
    foreach($server->getUsers() as $user){
        $server->send($user->socket, json_encode($return));
    }
}

function randomColor(){
	$color_array  = array("#f5f5f5","#ffe4e1","#778899","#0000ff","#00ffff","#006400","#00fa9a","#bdb76b","#f0e68c","#a0522d","#fa8072","#db7093","#9932cc","#696969","#fffaf0","#fff0f5","#708090","#1e90ff","#00ffff","#008000","#7cfc00","#eee8aa","#ffff00","#8b4513","#ffa07a","#ffc0cb","#9400d3","#808080","#faf0e6","#fff5ee","#2f4f4f","#6495ed","#40e0d0","#228b22","#7fff00","#fff8dc","#ffd700","#800000","#ff7f50","#ffb6c1","#8b008b","#a9a9a9","#faebd7","#fdf5e6","#b0c4de","#00bfff","#48d1cc","#3cb371","#adff2f","#f5f5dc","#ffa500","#8b0000","#ff6347","#d8bfd8","#800080","#c0c0c0","#ffefd5","#fffff0","#4682b4","#87cefa","#00ced1","#8fbc8f","#00ff00","#ffffe0","#f4a460","#a52a2a","#ff4500","#ff00ff","#4b0082","#d3d3d3","#ffebcd","#f0fff0","#4169e1","#87ceeb","#20b2aa","#66cdaa","#32cd32","#fafad2","#ff8c00","#b22222","#ff0000","#ff00ff","#483d8b","#dcdcdc","#ffe4c4","#f5fffa","#191970","#add8e6","#5f9ea0","#7fffd4","#9acd32","#fffacd","#daa520","#cd5c5c","#dc143c","#ee82ee","#8a2be2","#ffffff","#ffe4b5","#f0ffff","#000080","#b0e0e6","#008b8b","#98fb98","#6b8e23","#f5deb3","#cd853f","#bc8f8f","#c71585","#dda0dd","#9370db","#fffafa","#ffdead","#f0f8ff","#00008b","#afeeee","#008080","#90ee90","#808000","#deb887","#b8860b","#e9967a","#ff1493","#da70d6","#6a5acd","#f8f8ff","#ffdab9","#e6e6fa","#0000cd","#e0ffff","#2e8b57","#00ff7f","#556b2f","#d2b48c","#d2691e","#f08080","#ff69b4","#ba55d3","#7b68ee",);
	return $color_array[rand (0 , count($color_array)-1 )];
}

