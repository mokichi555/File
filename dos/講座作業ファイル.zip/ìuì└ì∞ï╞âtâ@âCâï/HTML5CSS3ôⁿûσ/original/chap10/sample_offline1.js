window.onload=function(){
    if(navigator.onLine){
        document.getElementById("info").innerHTML = 'オンラインです';
    }else{
        document.getElementById("info").innerHTML = 'オフラインです';
    }
}
