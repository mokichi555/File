<?php
$log_file = "post.txt";

$fp = @fopen($log_file, "a");
if($fp){
    flock($fp,LOCK_EX);
    fwrite($fp,$_POST['text'] ."\n");
}
fclose($fp);

header("HTTP/1.1 200 OK");
?>