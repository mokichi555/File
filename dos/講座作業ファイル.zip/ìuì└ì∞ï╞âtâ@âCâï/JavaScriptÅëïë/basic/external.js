//関数の定義
function getAreaOfTriangle(base, height){
	
	//面積
	var area;
	
	//面積の計算
	area = base * height / 2;
	
	//戻り値
	return area;
	
}