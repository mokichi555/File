//Personalオブジェクト
var Personal = function(){
	
	/*
	プロパティは何かを記録するもの。メソッドは何かの処理を行うもの。
	オブジェクト内で定義されるプロパティやメソッドを「メンバ」と称する。
	*/
	
	//nameプロパティ
	this.name;
	
	//ageプロパティ
	this.age;
};

//自己紹介するメソッド
Personal.prototype.introduction = function(){
	document.write("私の名前は" + this.name + "で、年齢は" + this.age + "歳です。<br/>");
};