//Familyオブジェクト
var Family = function(){
	
	//これらのプロパティはPersonalオブジェクト型
	this.father = new Personal("お父さん", 40);
	this.mother = new Personal("お母さん", 30);
	this.boku = new Personal("僕", 10);
};