//Personalオブジェクト
var Personal = function(name, age){
	
	//nameプロパティはstring型
	this.name = name;
	
	//ageプロパティはnumber型
	this.age = age;
};

//自己紹介するメソッド
Personal.prototype.introduction = function(){
	document.write("私の名前は" + this.name + "で、年齢は" + this.age + "歳です。<br/>");
};