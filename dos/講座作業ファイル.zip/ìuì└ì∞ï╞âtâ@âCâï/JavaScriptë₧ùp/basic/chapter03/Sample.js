//Sampleオブジェクト
var Sample = function(){
	
	//通常のプロパティ
	this.property;
};

//通常のメソッド
Sample.prototype.method = function(){
	document.write("プロパティの値は" + this.property + "<br/>");
};

//静的プロパティ
Sample.staticProperty;

//静的メソッド
Sample.staticMethod = function(){
	document.write("静的プロパティの値は" + Sample.staticProperty + "<br/>");
};