//Personalオブジェクト
var Personal = function(name, age){	//コンストラクタへの引数
	
	//nameプロパティ
	this.name = name;	//プロパティを初期化
	
	//ageプロパティ
	this.age = age;		//プロパティを初期化
};

//自己紹介するメソッド
Personal.prototype.introduction = function(){
	document.write("私の名前は" + this.name + "で、年齢は" + this.age + "歳です。<br/>");
};