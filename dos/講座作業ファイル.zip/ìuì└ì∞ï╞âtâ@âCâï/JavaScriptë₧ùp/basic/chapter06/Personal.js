//Personalオブジェクト
var Personal = function(name, age){
	
	//nameプロパティ
	this.name = name;
	
	//ageプロパティ
	this.age = age;
};

//自己紹介するメソッド
Personal.prototype.introduction = function(){
	document.write("私の名前は" + this.name + "で、年齢は" + this.age + "歳です。<br/>");
};