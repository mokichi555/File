<?php
	
	//スーパーグローバル変数「$_GET」でパラメータを参照
	$text = $_GET["text"];
	$radio = $_GET["radio"];
	$select_single = $_GET["select_single"];
	$textarea = $_GET["textarea"];
	
	//issetで変数がセットされているか（NULLじゃないか）を判別する
	$checkbox = "";
	if(isset($_GET["checkbox"]) == TRUE){
		
		//パラメータcheckboxは配列
		$array = $_GET["checkbox"];
		foreach($array as $value){
			$checkbox .= $value;
		}
	}
	
	$select_multi = "";
	if(isset($_GET["select_multi"]) == TRUE){
		
		//パラメータselect_multiは配列
		$array = $_GET["select_multi"];
		foreach($array as $value){
			$select_multi .= $value;
		}
	}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja">
	<head>
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
		<title>入力フォームその2の結果</title>
	</head>
	<body>
		<table border="1">
			<tbody>
				<tr>
					<td>テキスト</td>
					<td><?php print($text); ?></td>
				</tr>
				<tr>
					<td>チェックボックス</td>
					<td><?php print($checkbox); ?></td>
				</tr>
				<tr>
					<td>ラジオ</td>
					<td><?php print($radio); ?></td>
				</tr>
				<tr>
					<td>セレクト（単行）</td>
					<td><?php print($select_single); ?></td>
				</tr>
				<tr>
					<td>セレクト（複行）</td>
					<td><?php print($select_multi); ?></td>
				</tr>
				<tr>
					<td>テキストエリア</td>
					<td>
						<?php
							/*	
							str_replace(置換対象文字,置換文字,文字列)、文字列内の置換対象文字を置換文字に置換する関数
							PHP_EOLは改行コード
							*/
							print(str_replace(PHP_EOL,'<br />',$textarea));
						?>
					</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>