<?php

//リクエストパラメータを3秒後に返信する
$parameter = $_REQUEST['parameter'];
sleep(3);

//データをプレーンテキストで返信する
header('content-type:text/plain; charset=UTF-8');
print($parameter);