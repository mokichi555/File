<?php

//リクエストパラメータ「base」に底辺、「height」に高さを送信すると三角形の面積を出力するサーバサイドスクリプト
$base = $_REQUEST['base'];
$height = $_REQUEST['height'];
$area = (float)$base * (float)$height / 2;
print($area);