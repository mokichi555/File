<?php

//現在の日時をHTML形式で返信する
header('content-type:text/html; charset=UTF-8');
print(@date('Y/m/d H:i:s'));