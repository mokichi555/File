<?php

//データが見つからない場合は空にする
$json = '[]';

//リクエストパラメータ「genre」を取得
if(isset($_REQUEST['genre']) == true && $_REQUEST['genre'] != ''){
	$parameter = $_REQUEST['genre'];
}
else{
	goto end;
}

//ジャンルごとの各スポーツ
if($parameter == "ball"){
	$json = "[{\"name\":\"野球\"},{\"name\":\"サッカー\"},{\"name\":\"バスケットボール\"}]";
}
else if($parameter == "track"){
	$json = "[{\"name\":\"短距離走\"},{\"name\":\"走り幅跳び\"},{\"name\":\"ハードル\"}]";
}
else if($parameter == "combat"){
	$json = "[{\"name\":\"空手\"},{\"name\":\"柔道\"},{\"name\":\"ボクシング\"}]";
}

end:

//データをjson形式で返信する
header('content-type:application/json; charset=UTF-8');
print($json);