<?php

//データが見つからない場合は空にする
$json = '[]';

//リクエストパラメータ「zip」を取得
if(isset($_REQUEST['zip']) == true && $_REQUEST['zip'] != ''){
	$parameter = $_REQUEST['zip'];
}
else{
	goto end;
}

//TOKYO.CSVを読み込む
$fp = fopen('./tokyo.csv', 'rb');
while($row = fgetcsv($fp)){
	
	$zip = $row[2];
	$state = $row[6];
	$city = $row[7];
	$address = $row[8];
	
	//該当データをJSON形式にする
	if($parameter == $zip){
		$json = "{\"zip\":\"{$zip}\",\"state\":\"{$state}\",\"city\":\"{$city}\",\"address\":\"{$address}\"}";
		break;
	}
}
fclose($fp);

end:

//データをjson形式で返信する
header('content-type:application/json; charset=UTF-8');
print($json);